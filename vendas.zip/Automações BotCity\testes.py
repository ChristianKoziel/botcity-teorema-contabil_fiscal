        if not bot.find( "crm_btn_incluir_princ_24_07", matching=0.97, waiting_time=10000):
            not_found("crm_btn_incluir_princ_24_07")
        bot.click()
        if not bot.find( "crm_btn_nao_incluir_dados", matching=0.97, waiting_time=10000):
            not_found("crm_btn_nao_incluir_dados")
        bot.click()
        if not bot.find( "crm_btn_localizar_opc1_2407", matching=0.97, waiting_time=10000):
            not_found("crm_btn_localizar_opc1_2407")
        bot.click()
        if not bot.find( "crm_btn_selecionar_opc1_2407", matching=0.97, waiting_time=10000):
            not_found("crm_btn_selecionar_opc1_2407")
        bot.click()
        if not bot.find( "crm_btn_retornar_opc1_2407", matching=0.97, waiting_time=10000):
            not_found("crm_btn_retornar_opc1_2407")
        bot.click()
        if not bot.find( "crm_btn_salvar_opc1_2407", matching=0.97, waiting_time=10000):
            not_found("crm_btn_salvar_opc1_2407")
        bot.click()
        if not bot.find( "crm_btn_retornar_opc1_2407", matching=0.97, waiting_time=10000):
            not_found("crm_btn_retornar_opc1_2407")
        bot.click()
        if not bot.find( "crm_btn_editar_opc1_2407", matching=0.97, waiting_time=10000):
            not_found("crm_btn_editar_opc1_2407")
        bot.click()
        if not bot.find( "crm_btn_excluir_opc1_2407", matching=0.97, waiting_time=10000):
            not_found("crm_btn_excluir_opc1_2407")
        bot.click()
        if not bot.find( "crm_botao_nao_importar_dados", matching=0.97, waiting_time=10000):
            not_found("crm_botao_nao_importar_dados")
        bot.click()
        

        
        if not bot.find( "fatu_cad_itens_btn_incluir_estoque", matching=0.97, waiting_time=10000):
            not_found("fatu_cad_itens_btn_incluir_estoque")
        bot.click()
        
        if not bot.find( "fatu_cad_btn_localizar_cad_itens", matching=0.97, waiting_time=10000):
            not_found("fatu_cad_btn_localizar_cad_itens")
        bot.click()
        if not bot.find( "fatu_btn_selecionar_opc2_2503", matching=0.97, waiting_time=10000):
            not_found("fatu_btn_selecionar_opc2_2503")
        bot.click()
        
        if not bot.find( "fatu_cad_clientes_transp_selecionar_24", matching=0.97, waiting_time=10000):
                    not_found("fatu_cad_clientes_transp_selecionar_24")
                bot.click()
        
















