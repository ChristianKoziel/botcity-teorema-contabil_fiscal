#!/bin/bash

zip -r "vendas.zip" * -x "vendas.zip"